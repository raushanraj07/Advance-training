package com.even;

import java.util.Scanner;

public class Even {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		
		int n,i=0;
		
		
		System.out.println("enter the value of n: ");
		n=sc.nextInt();
		System.out.println("even numbers are ");
		for(i=1; i<n; i++)
		{
			if(i%2==0)
				
				System.out.println(i);
			
		}
		System.out.println();
	}

}
