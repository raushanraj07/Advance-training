package com.book1;
import com.book.*;
public class Book1 {

	
	
	public void createBooks() {
		Book b[]=new Book[2];
		b[0]=new Book("Java Programming", 350.50);
		b[1]=new Book("Let us c", 250);
		for(int i=0;i<b.length;i++) {
			b[i].display();
			System.out.println(" ");
		}
		
		}
	public void showBooks() {
		createBooks();
	}
	public static void main(String[] args) {
		
	  Book1 bk=new Book1();
	  bk.showBooks();

	}

}
