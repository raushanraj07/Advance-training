package com.book;

public class Book {

	
		String booktitle;
	   double  price;

	
       public Book(String b, double p) {
    	   booktitle=b;
    	   price=p;
    	   
       }


	public String getBooktitle() {
		return booktitle;
	}


	public void setBooktitle(String booktitle) {
		this.booktitle = booktitle;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}
    public void display() {
	System.out.println("Booktitle is "+booktitle);
	System.out.println("price of book is "+price);
}

}