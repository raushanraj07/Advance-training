package com.rectangle;

import java.util.Scanner;

public class Rectangle {

	
	
		public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
		double length;
		double width;
		double area;
		public Rectangle()
		
		{
			length=0;
			width=0;
		}
        public Rectangle(double l, double wid)
        {
        	
        	length=l;
        	width=wid;
        	
        }
         
            public void input() {
            Scanner in = new Scanner(System.in);
            System.out.print("Enter length of rectangle: ");
            length = in.nextInt();
            System.out.print("Enter breadth of rectangle: ");
            width = in.nextInt();
	
        }
         public double getArea()
        {
        	area=length*width;
        	return area;
         }
	      public void display() {
		 System.out.println("Area of rectangle "+area);
	}
}
