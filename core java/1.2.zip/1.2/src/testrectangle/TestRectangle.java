package testrectangle;

import com.rectangle.Rectangle;

public class TestRectangle {

	public static void main(String[] args) {
		
		Rectangle rt1= new Rectangle();
		rt1.input();
		rt1.getArea();
		rt1.display();
		Rectangle rt2=new Rectangle();
		rt2.input();
		rt2.getArea();
		rt2.display();
		Rectangle rt3=new Rectangle();
		rt3.input();
		rt3.getArea();
		rt3.display();
		Rectangle rt4=new Rectangle();
		rt4.input();
		rt4.getArea();
		rt4.display();
		Rectangle rt5=new Rectangle();
		rt5.input();
		rt5.getArea();
		rt5.display();
		
		
		
		
		
	}

}
