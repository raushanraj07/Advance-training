package com.core;

import java.util.Scanner;

public class RectangleModification {

	int length;
	int width;
	double area;
	double perimeter;
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public RectangleModification() {
		length=1;
		width=1;
		
	}
	public RectangleModification(int l, int wid) {
		this.length=l;
		this.width=wid;
		
	}
	public void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length of rectangle: ");
		length=sc.nextInt();
		System.out.println("Enter width of rectangle: ");
		width=sc.nextInt();
		
	}
	public void area() {
		area=length*width;
		
	}
	public void perimeterRectangle() {
		perimeter=2*(length+width);
		
	}
   public void display() {
	   if(length>0 && length<20)
	   System.out.println("Area of rectangle "+area);
	   System.out.println("perimeter of rectangle "+perimeter);
   }
}
