package com.rectangle2;

import com.core.RectangleModification;

public class Main {

	public static void main(String[] args) {
		
		
		RectangleModification rtm=new RectangleModification();
		rtm.input();
		rtm.area();
		rtm.perimeterRectangle();
		rtm.display();
		
		RectangleModification rtm2=new RectangleModification();
		rtm2.input();
		rtm2.area();
		rtm2.perimeterRectangle();
		rtm2.display();
		
		RectangleModification rtm3=new RectangleModification();
		rtm3.input();
		rtm3.area();
		rtm3.perimeterRectangle();
		rtm3.display();
	}

}
